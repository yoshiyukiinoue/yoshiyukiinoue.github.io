# Inoue High-Energy Astrophysics Lab — Website (たたき台)

芝浦工業大学・高エネルギー宇宙物理研究室(井上研)のウェブサイト。
Hugo + Hugo Blox (Research Group テンプレート)、日英2言語。

## セットアップ手順

1. **テンプレートからリポジトリを作る**
   https://github.com/HugoBlox/theme-research-group で「Use this template」
   → 既存の `yoshiyukiinoue.github.io` リポジトリに統合する場合は、
   テンプレートの `go.mod`, `go.sum`, `assets/`, `static/` を持ってくる。

2. **このたたき台の `config/` と `content/` で上書き**
   - `config/_default/` … 多言語(ja ルート / en サブパス)・メニュー設定済み
   - `content/ja/`, `content/en/` … ページ骨格(TODO コメント入り)

3. **ローカルプレビュー**
   ```
   hugo server
   ```
   (Hugo extended + Go が必要。バージョンはテンプレートの推奨に従う)

4. **論文リストの生成**
   ```
   pipx install academic
   export ADS_DEV_KEY=<SciX API token>
   ./scripts/fetch_publications.sh
   ```
   SciX 公開ライブラリ(全論文: r0HdPWXHQKOV8kUwuZDq5Q)から BibTeX を取得し、
   `content/{ja,en}/publication/` に論文ページを自動生成する。

5. **デプロイ**
   `main` に push すると GitHub Actions (`.github/workflows/deploy.yml`) が
   GitHub Pages にデプロイ。リポジトリ Settings → Pages → Source を
   「GitHub Actions」に変更しておくこと。

## 旧サイトからの移行マップ

| 旧 (Beautiful Hugo)       | 新                                   |
|---------------------------|--------------------------------------|
| Profile                   | `content/{ja,en}/authors/yinoue/`    |
| Team                      | `content/{ja,en}/people/` + authors/ |
| Research                  | `content/{ja,en}/research/`(3本柱) |
| Publication               | `content/{ja,en}/publication/`(自動生成) |
| Talk                      | publication と統合 or `talks/` 新設  |
| Lecture                   | `content/{ja,en}/teaching/`          |
| Downloads                 | `static/uploads/` + teaching から参照 |
| 旧ブログ記事              | `content/ja/news/`(必要分のみ移行) |

## TODO

- [ ] PI プロフィールの経歴・ORCID 等を確認(`<!-- TODO -->` で検索)
- [ ] ヒーロー画像 `assets/media/hero.jpg` を配置(Fermi LAT 画像のクレジット確認)
- [ ] メンバー(Hosono, Hamamoto, Varma, Gerhart, Han ほか)の authors ページ作成
- [ ] 旧サイトの URL からのリダイレクト(`aliases:` front matter で対応可)
