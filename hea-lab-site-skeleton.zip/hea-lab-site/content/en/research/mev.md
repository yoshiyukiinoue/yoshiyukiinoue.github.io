---
title: High-Energy Astrophysics (MeV Gamma Rays)
summary: MeV gamma-ray astronomy with COSI and GRAMS, and multi-messenger studies
weight: 20
---

The MeV band is often called the last frontier of observational astronomy.
We participate in NASA's COSI mission and the GRAMS balloon project, forecasting the MeV sky,
studying particle acceleration in AGN coronae, hunting the sources of IceCube neutrinos,
and investigating blazar populations.
