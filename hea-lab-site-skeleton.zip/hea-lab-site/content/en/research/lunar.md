---
title: Lunar Radiation Environment
summary: Understanding and forecasting radiation on the lunar surface
weight: 30
---

For the coming era of sustained human activity on the Moon, we apply the tools of high-energy
astrophysics to understand and forecast the radiation environment produced by galactic cosmic rays
and solar energetic particles on the lunar surface.
