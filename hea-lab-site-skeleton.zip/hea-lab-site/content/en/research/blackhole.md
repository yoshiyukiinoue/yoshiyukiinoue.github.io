---
title: Black Hole Astrophysics
summary: Magnetic fields of black hole coronae and accretion physics
weight: 10
---

Building on the first measurement of magnetic fields in AGN coronae (Inoue & Doi 2018),
we combine ALMA millimeter synchrotron observations, IXPE X-ray polarimetry, and XRISM high-resolution
spectroscopy to reveal the physics of plasma, magnetic fields, and particle acceleration
in the immediate vicinity of black holes.
