---
title: Publications
---

The publication list is auto-generated from our public SciX (ADS) libraries.
See `scripts/fetch_publications.sh`.

- All publications: <https://scixplorer.org/public-libraries/r0HdPWXHQKOV8kUwuZDq5Q>
- First-author publications: <https://scixplorer.org/public-libraries/y6gd-hluToy04aYaA8e7RA>
