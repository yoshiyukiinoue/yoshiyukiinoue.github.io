---
title: Inoue High-Energy Astrophysics Lab
type: landing

sections:
  - block: markdown
    id: hero
    content:
      title: Inoue High-Energy Astrophysics Lab
      subtitle: Shibaura Institute of Technology, Omiya Campus
      text: |
        From the extreme environments around black holes to the radiation environment on the lunar surface —
        we tackle the mysteries of the high-energy universe through theory and multi-messenger observations
        (X-rays, MeV gamma rays, radio, neutrinos, and gravitational waves).
    design:
      background:
        image:
          filename: hero.jpg
          filters:
            brightness: 0.6
        text_color_light: true

  - block: markdown
    id: research-pillars
    content:
      title: Research Pillars
      text: |
        ### 🕳️ Black Hole Astrophysics
        Magnetic field measurements of black hole coronae (ALMA, IXPE, XRISM), accretion physics, and extreme physics near the event horizon.
        [Read more →](research/blackhole/)

        ### ☄️ High-Energy Astrophysics (MeV Gamma Rays)
        Pioneering MeV gamma-ray astronomy with COSI and GRAMS, multi-messenger studies with IceCube neutrinos, and blazar population studies.
        [Read more →](research/mev/)

        ### 🌕 Lunar Radiation Environment
        Understanding and forecasting the cosmic-ray and radiation environment on the lunar surface for the era of human lunar activity.
        [Read more →](research/lunar/)

  - block: collection
    id: news
    content:
      title: News
      count: 5
      filters:
        folders: [news]
    design:
      view: date-title-summary

  - block: collection
    id: latest-pubs
    content:
      title: Recent Publications
      count: 5
      filters:
        folders: [publication]
    design:
      view: citation

  - block: markdown
    id: join-cta
    content:
      title: Join Us
      text: |
        We are recruiting graduate students (MSc/PhD), postdocs, and undergraduates.
        Black holes, gamma rays, neutrinos, or the Moon — if any of these excites you, get in touch.
        [How to join →](join/)
---
