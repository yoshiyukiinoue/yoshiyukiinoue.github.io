---
title: People
type: landing
sections:
  - block: people
    content:
      title: People
      user_groups: [PI, Postdocs, PhD Students, Masters Students, Undergraduates, Alumni]
    design:
      show_interests: true
      show_role: true
      show_organizations: false
---
