---
title: 高エネルギー天文学(MeVガンマ線)
summary: COSI・GRAMS によるMeVガンマ線天文学とマルチメッセンジャー研究
weight: 20
---

MeV ガンマ線帯域は「最後の観測フロンティア」と呼ばれる未開拓領域です。
当研究室は NASA の COSI 衛星や気球実験 GRAMS に参画し、
MeV 帯域の全天予測、AGN コロナでの粒子加速、IceCube ニュートリノ源の解明、
ブレーザー population 研究を進めています。

<!-- TODO: COSI/GRAMS の紹介、MeV 全天マップ予測図、ニュートリノ関連の成果 -->
