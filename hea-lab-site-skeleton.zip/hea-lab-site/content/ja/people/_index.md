---
title: メンバー
type: landing
sections:
  - block: people
    content:
      title: メンバー
      user_groups: [PI, 研究員, 博士課程, 修士課程, 学部生, 卒業生]
    design:
      show_interests: true
      show_role: true
      show_organizations: false
---
