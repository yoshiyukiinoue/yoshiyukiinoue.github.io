---
title: 高エネルギー宇宙物理研究室
type: landing

sections:
  - block: markdown
    id: hero
    content:
      title: 高エネルギー宇宙物理研究室(井上研)
      subtitle: 芝浦工業大学 大宮キャンパス
      text: |
        ブラックホール近傍の極限環境から月面の放射線環境まで——
        理論とマルチメッセンジャー観測(X線・MeVガンマ線・電波・ニュートリノ・重力波)を駆使して、
        高エネルギー宇宙の謎に挑みます。
    design:
      background:
        image:
          filename: hero.jpg
          filters:
            brightness: 0.6
        text_color_light: true

  - block: markdown
    id: research-pillars
    content:
      title: 研究の3本柱
      text: |
        ### 🕳️ ブラックホール天文学
        ブラックホール近傍コロナの磁場測定(ALMA・IXPE・XRISM)、降着流の物理、事象の地平線近傍の極限物理。
        [詳しく →](research/blackhole/)

        ### ☄️ 高エネルギー天文学(MeVガンマ線)
        COSI・GRAMS によるMeVガンマ線天文学の開拓、IceCubeニュートリノとのマルチメッセンジャー研究、ブレーザー population 研究。
        [詳しく →](research/mev/)

        ### 🌕 月面放射線環境
        有人月面活動時代に向けた、月面の宇宙線・放射線環境の理解と予測。
        [詳しく →](research/lunar/)

  - block: collection
    id: news
    content:
      title: ニュース
      count: 5
      filters:
        folders: [news]
    design:
      view: date-title-summary

  - block: collection
    id: latest-pubs
    content:
      title: 最近の論文
      count: 5
      filters:
        folders: [publication]
    design:
      view: citation

  - block: markdown
    id: join-cta
    content:
      title: メンバー募集
      text: |
        大学院生(修士・博士)・博士研究員・卒研生を募集しています。
        ブラックホール、ガンマ線、ニュートリノ、月——どれか一つでもピンと来たら、まずは気軽に連絡してください。
        [参加希望の方へ →](join/)
---
